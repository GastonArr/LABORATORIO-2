<div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
        <li>
            <a href="registro.php"><i class="fa fa-dashboard fa-fw"></i> Form Registro</a>
        </li>
        

    </ul>
</div>       