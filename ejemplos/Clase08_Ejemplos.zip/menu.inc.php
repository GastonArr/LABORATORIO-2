<div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
        <li>
            <a href="Ejemplo1.php"><i class="fa fa-edit fa-fw"></i> Ejemplo 1 - Login con Log</a>
        </li>
        <li>
            <a href="Ejemplo2.php"><i class="fa fa-dashboard fa-fw"></i> Ejemplo 2 - Login con acceso correcto</a>
        </li>
        
        <li>
            <a href="Tarea1.php"><i class="fa fa-files-o fa-fw"></i> Tarea 1</a>
        </li>
    </ul>
</div>